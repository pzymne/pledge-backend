# pledge-backend

The project is divided into two parts, one is API and the other is scheduled task

API

    cd api
    go run pledge_api.go

pool task

    cd schedule
    go run pledge_task.go